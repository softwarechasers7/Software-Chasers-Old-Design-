<?php
// variable setting
$name * = $_REQUEST['name *'];
$email * = $_REQUEST['Email *'];
$phone  = $_REQUEST['phone'];
$company name = $_REQUEST['company name'];
$subject * = $_REQUEST['subject *'];
$message * = $_REQUEST['Message *'];

//check input fields
if (empty($name *) || empty($email *) || (empty($phone) || (empty($company name) ||  (empty($subject *) || empty($message *))
{
    echo "Please fill the fields";
}
else
{
    mail("softwarechasers23@gmail.com", "Email form", $message , "From: $name <$email>" );
    echo "<script type='text/javascript'>alert('your message send successfully');
        window.history.log(-1);
    </script>";
}
?>